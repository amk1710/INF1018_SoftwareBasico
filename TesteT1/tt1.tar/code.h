#include <stdio.h>
int code (char *desc, void* v, FILE *f);
int decode (FILE *f);
